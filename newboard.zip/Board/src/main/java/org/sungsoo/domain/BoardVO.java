package org.sungsoo.domain;

import java.util.Date;

import lombok.Data;

@Data
public class BoardVO {
	
	private Integer bno,viewcnt;
	private String writer,content,title;
	private Date regdate;
	

}
