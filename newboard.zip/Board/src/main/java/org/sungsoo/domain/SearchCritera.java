package org.sungsoo.domain;

import lombok.Data;

@Data
public class SearchCritera extends Criteria{
	
	private String keyword;
	private String searchType;

}
