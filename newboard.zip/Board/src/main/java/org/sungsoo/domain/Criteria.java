package org.sungsoo.domain;

import lombok.Data;

@Data
public class Criteria {
	private Integer page, perPageNum;

	public Criteria() {
		this.page = 1;
		this.perPageNum = 10;
	}
	public void setPage(Integer page) {
		if(page<=0) {
			this.page=1;
			return;
		}
		this.page=page;
	}
	public void setPerPageNum(Integer perPageNum) {
		if(perPageNum<=0||perPageNum>1000) {
			this.perPageNum=10;
			return;
		}
		this.perPageNum=perPageNum;
	}
	public int getPage() {
		return page;
	}
	public int getPerPageNum() {
		return this.perPageNum;
	}

	public int getPageStart() {
		return (this.page-1)*perPageNum;
	}
	
	
	
}
