package org.sungsoo.service;

import java.util.List;

import org.sungsoo.domain.BoardVO;

public interface BoardService {
	
	public void regist(BoardVO vo);
	
	public BoardVO read(Integer bno);
	
	public void modify(BoardVO vo);
	
	public void remove(Integer bno);
	
	public List<BoardVO> listAll();

}
