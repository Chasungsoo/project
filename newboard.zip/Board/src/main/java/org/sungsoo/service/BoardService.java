package org.sungsoo.service;

import java.util.List;

import org.sungsoo.domain.BoardVO;
import org.sungsoo.domain.Criteria;

public interface BoardService {
	
	public void regist(BoardVO vo);
	
	public BoardVO read(Integer bno);
	
	public void modify(BoardVO vo);
	
	public void remove(Integer bno);
	
	public List<BoardVO> listAll();
	
	public List<BoardVO> listpage(Integer page);
	
	public List<BoardVO> listCriteria(Criteria cri);
	
	public int listCountCriteria(Criteria cri);

}
