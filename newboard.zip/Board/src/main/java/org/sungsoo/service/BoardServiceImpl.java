package org.sungsoo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.sungsoo.domain.BoardVO;
import org.sungsoo.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardMapper mapper;
	@Override
	public void regist(BoardVO vo) {
		// TODO Auto-generated method stub
		mapper.insert(vo);

	}

	@Override
	public BoardVO read(Integer bno) {
		// TODO Auto-generated method stub
		return mapper.selectRead(bno);
	}

	@Override
	public void modify(BoardVO vo) {
		// TODO Auto-generated method stub
		mapper.update(vo);
	}

	@Override
	public void remove(Integer bno) {
		// TODO Auto-generated method stub
		mapper.delete(bno);
	}

	@Override
	public List<BoardVO> listAll() {
		
		return mapper.selectList();
	}

}
