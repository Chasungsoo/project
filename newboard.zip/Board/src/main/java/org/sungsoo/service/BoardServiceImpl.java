package org.sungsoo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.sungsoo.domain.BoardVO;
import org.sungsoo.domain.Criteria;
import org.sungsoo.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardMapper mapper;
	@Override
	public void regist(BoardVO vo) {
		// TODO Auto-generated method stub
		mapper.insertList(vo);

	}

	@Override
	public BoardVO read(Integer bno) {
		// TODO Auto-generated method stub
		return mapper.selectRead(bno);
	}

	@Override
	public void modify(BoardVO vo) {
		// TODO Auto-generated method stub
		mapper.update(vo);
	}

	@Override
	public void remove(Integer bno) {
		// TODO Auto-generated method stub
		mapper.delete(bno);
	}

	@Override
	public List<BoardVO> listAll() {
		
		return mapper.selectList();
	}
	@Override
	public List<BoardVO> listpage(Integer page){
		if(page<=0) {
			page=1;
		}
		page=(page-1)*10;
		return mapper.listpage(page);
	}
	@Override
	public List<BoardVO> listCriteria(Criteria cri){
		return mapper.listCriteria(cri);
	}
	@Override 
	public int listCountCriteria(Criteria cri) {
		return mapper.countPaging(cri);
	}

}
