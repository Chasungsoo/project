package org.sungsoo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.sungsoo.domain.BoardVO;
import org.sungsoo.domain.Criteria;
import org.sungsoo.domain.PageMaker;
import org.sungsoo.service.BoardService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/board/*")
public class BoardController {

	@Setter(onMethod_ = @Autowired)
	private BoardService service;

	@GetMapping("/listPage")
	public void listAll(@ModelAttribute("cri")Criteria cri, Model model) {
		
		log.info(cri);
		model.addAttribute("list", service.listCriteria(cri));
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(cri);
		pageMaker.setTotalCount(service.listCountCriteria(cri));
		
		model.addAttribute("pageMaker", pageMaker);
	}



	@GetMapping("readPage")
	public void read(@RequestParam("bno") Integer bno,
			@ModelAttribute("cri") Criteria cri , Model model) {
		model.addAttribute(service.read(bno));
	}

	@GetMapping("/register")
	public void registerGET(BoardVO vo, Model model) {// 글등록 페이지
		log.info("register get...");

	}

	@PostMapping("/register")
	public String registerPOST(BoardVO vo, RedirectAttributes rttr) {// 등록페이지

		log.info("register post...");

		log.info(vo.toString());

		service.regist(vo);

		rttr.addFlashAttribute("msg", "SUCCESS");
		return "redirect:/board/listPage";
	}

	@PostMapping("/remove")
	public String removePOST(@RequestParam("bno") Integer bno,Criteria cri, RedirectAttributes rttr) {// 등록페이지

		log.info("remove post...");
		service.remove(bno);
		rttr.addAttribute("page",cri.getPage());
		rttr.addAttribute("perPageNum",cri.getPerPageNum());
		rttr.addFlashAttribute("msg", "SUCCESS");
		return "redirect:/board/listPage";
	}

	@GetMapping("/modify")
	public void modify(@RequestParam("bno") Integer bno,@ModelAttribute("cri") Criteria cri, Model model) {

		model.addAttribute(service.read(bno));

	}

	@PostMapping("/modify")
	public String modifyPost(BoardVO vo,Criteria cri, RedirectAttributes rttr) {
		service.modify(vo);
		rttr.addAttribute("page",cri.getPage());
		rttr.addAttribute("page",cri.getPerPageNum());
		rttr.addFlashAttribute("msg", "SUCCESS");
		return "redirect:/board/listPage";
	}

}
