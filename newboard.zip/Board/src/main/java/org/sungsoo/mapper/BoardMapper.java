package org.sungsoo.mapper;

import java.util.List;

import org.sungsoo.domain.BoardVO;
import org.sungsoo.domain.Criteria;

public interface BoardMapper {
	
	public List<BoardVO> selectList();  //목록불러오기

	public boolean insertList(BoardVO vo);  //글등록

	public BoardVO selectRead(Integer bno);  // 조회페이지 불러오기

	public boolean delete(Integer bno); //삭제

	public void update(BoardVO vo); //수정

	public List<BoardVO> listpage(Integer page);// 페이징처리

	public List<BoardVO> listCriteria(Criteria cri);//페이징처리
	
	public int countPaging(Criteria cri);

}
