package org.sungsoo.mapper;



import java.util.List;

import org.sungsoo.domain.BoardVO;

public interface BoardMapper {
	public List<BoardVO> selectList();
	public boolean insert(BoardVO vo);
	public BoardVO selectRead(Integer bno);
	public boolean delete(Integer bno);
	public void update(BoardVO vo);
	
	

}
