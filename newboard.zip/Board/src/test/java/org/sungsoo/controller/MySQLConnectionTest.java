package org.sungsoo.controller;

import java.sql.Connection;
import java.sql.DriverManager;

import org.junit.Test;

public class MySQLConnectionTest {
	
	private static final String DRIRVER="com.mysql.cj.jdbc.Driver";
	
	private static final String URL="jdbc:mysql://127.0.0.1:3306/sungsoo?useSSL=false&serverTimezone=Asia/Seoul";
	
	private static final String USER="bit04";
	private static final String PW="bit04";
	@Test
	public void testConnection() throws Exception{
		Class.forName(DRIRVER);
		
		try(Connection con = DriverManager.getConnection(URL, USER, PW)){
			System.out.println(con);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	

}
