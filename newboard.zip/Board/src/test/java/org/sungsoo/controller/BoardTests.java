package org.sungsoo.controller;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.sungsoo.domain.BoardVO;
import org.sungsoo.domain.Criteria;
import org.sungsoo.mapper.BoardMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})
@WebAppConfiguration
@Log4j
public class BoardTests {
	
	@Setter(onMethod_= @Autowired)
	private BoardMapper mapper;

//	@Test
//	public void testCreate() throws Exception{
//		
//		BoardVO vo= new BoardVO();
//		for(int i = 1; i <100 ;i++) {
//		vo.setTitle("Title = new board"+i);
//		vo.setContent("Content= helloworld"+i);
//		vo.setWriter("user"+i);
//		log.info(vo);
//		mapper.insertList(vo);
//		}
//		
//	}
//	@Test
//	public void delete() throws Exception{
//		
//		mapper.delete(1);
//	}
//	@Test
//	public void test() {
//		int page=4;
//		List<BoardVO> list = mapper.listpage(page);
//		for(BoardVO boardVO: list) {
//			log.info(boardVO.getBno()+":"+boardVO.getTitle());
//		}
//	}
	@Test
	public void testlist() {
		Criteria cri = new Criteria();
		
		cri.setPage(2);
		cri.setPerPageNum(20);
		List<BoardVO> list=mapper.listCriteria(cri);
		for(BoardVO boardVO:list) {
			log.info(boardVO.getBno()+":"+boardVO.getTitle());
		}
	}
}
