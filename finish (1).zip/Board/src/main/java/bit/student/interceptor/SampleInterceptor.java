package bit.student.interceptor;

import java.lang.reflect.Method;
import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.Response;

import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import lombok.extern.log4j.Log4j;

@Log4j
public class SampleInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		int bnonumber = Integer.parseInt(request.getParameter("bno"));  // 현재 클릭게시물의 bno 를 가져옴
		String bnostring = "" + bnonumber; 								// 쿠키벨류에 추가하기위해 형변환

		System.out.println("pre handle");
	
		Cookie[] cookies = request.getCookies(); 						//인터셉트 프리핸들에서 사용 가능한 리퀘스트를 이용하여 클라이언트로부터 쿠키를 가저온다

		int i = 0;						
		String cookieName = "";											//쿠키네임을 문자열로 저장 하기위한 변수
		for (i = 0; i < cookies.length; i++) {
			cookieName = cookieName + cookies[i].getName();
			
			if (cookieName.contains("bno")) {			//1.bno라는 쿠키가 있니?
				System.out.println("쿠키 이름중에 bno가 있다!");
				break;										//2.쿠키가 이미 있으니 이제 벨류를 체크하러 break;->6번으로
			} else {
				System.out.println("쿠키 이름중에 bno 가없으니 만들어주고 컨트롤러로");
				Cookie bno = new Cookie("bno",bnostring+"_");  //3.bno 쿠키가 없으니 bno 쿠키를 만들어 주고 
				response.addCookie(bno);					//4.bno 쿠키를 클라이언트에 보낸다 
				return true; 								//5. 컨트롤러로~(카운트증가해야함)
			}
		}

		if (cookies[i].getValue().contains(bnostring)) {//6.현재게시물의 bno를 클릭한적 있니?
			System.out.println("쿠키 벨류중에 bnostring 이 있따!"); //7.새로고침했을경우or 두번째 클릭했을경우.
			String newValue2=cookies[i].getValue()+"_";
			cookies[i].setValue(newValue2);
			response.addCookie(cookies[i]);	
			return true;									//8.컨트롤러로~(카운트증가 x)
		} 
		else {												//9.쿠키는 있으나 해당bno번 게시물은 처음방문이니 bno 쿠키에 벨류를 추가해주자 
				
			String newValue = cookies[i].getValue()+bnostring;//10._바로 구분하여  새로운 bno 추가해준다~
			cookies[i].setValue(newValue);						  //11.셋벨류~
			response.addCookie(cookies[i]);						  //12.클라이언트로 쏴주고
		
			return true;
		}
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
		System.out.println("post handle");


	}

}
