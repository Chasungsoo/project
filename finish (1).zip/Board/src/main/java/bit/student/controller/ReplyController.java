package bit.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import bit.student.domain.BoardVO;
import bit.student.domain.ReplyVO;
import bit.student.dto.PagingDTO;
import bit.student.mapper.BoardMapper;
import bit.student.mapper.ReplyMapper;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@CrossOrigin
@RequestMapping("/board/*")
public class ReplyController {
	@Setter(onMethod_ = @Autowired)	
	ReplyMapper mapper;
	
	@Setter(onMethod_ = @Autowired)	
	BoardMapper mapper2;
	
	@PostMapping("/replyDelete")
	public String Replydelete(Integer rno) {
		
		mapper.delete(rno);
		
		
		return "board/read";
		
	}
	@PostMapping("/ReplyInsert")
	public String ReplyInsert(ReplyVO vo,Model model,PagingDTO dto) {
		log.info("인설트 리플 정보 "+vo);
		BoardVO board=mapper2.selectRead(vo.getBno());
		mapper.insertReply(vo);
		List<ReplyVO> list=mapper.replyList(vo.getBno());
		log.info(board);
		model.addAttribute("replyList", list);
		model.addAttribute("board",board);
		model.addAttribute("dto",dto);
		return "/board/read";
		
	}
	

}
