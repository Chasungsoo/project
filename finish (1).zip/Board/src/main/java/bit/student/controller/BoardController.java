package bit.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import bit.student.domain.BoardVO;
import bit.student.domain.ReplyVO;
import bit.student.dto.AlterDTO;
import bit.student.dto.PageMaker;
import bit.student.dto.PagingDTO;
import bit.student.mapper.BoardMapper;
import bit.student.mapper.ReplyMapper;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@CrossOrigin
@RequestMapping("/board/*")
public class BoardController {

	@Setter(onMethod_ = @Autowired)
	BoardMapper mapper;
	@Setter(onMethod_ = @Autowired)	
	ReplyMapper rmapper;

	@GetMapping("/list")// 목록 페이지
	public List<BoardVO> list(PagingDTO dto, Model model, Integer bno) {

		log.info("get List.............");

		List<BoardVO> list = mapper.selectList(dto);// 받은 페이지+amount로 페이징하여 리시트를 뿌려줌
		
		log.info("BoardVO="+list);
		model.addAttribute("selectList", list);
		int total = mapper.listCount(dto);			//페이징처리
		PageMaker pm = new PageMaker(dto, total);
		model.addAttribute("pm", pm);

		return list;
	}

	@PostMapping("/list") //수정페이지->삭제버튼 click시 이동 페이지
	public String deletelist(PagingDTO dto, Model model, Integer bno) {
		log.info(bno);
		log.info("post List.............");
		mapper.delete(bno);   						//게시물번호의 글을 삭제
		List<BoardVO> list = mapper.selectList(dto);//삭제된 리스트를 다시뿌려줌
		model.addAttribute("selectList", list);
		int total = mapper.listCount(dto);          //페이징처리;
		PageMaker pm = new PageMaker(dto, total);
		log.info(pm);
		model.addAttribute("pm", pm);
		return "board/list";
	}

	@GetMapping("/read") //조회페이지
	public String readpage(@CookieValue(value="bno",required=false,defaultValue="0") 
	String value,  Integer bno, Model model, PagingDTO dto) {
		
		if(value.contains(bno+"_")) {//_bno 같지 않으면    
		log.info("처음이아니네?");
		    BoardVO board = mapper.selectRead(bno);  //클릭한 게시물 제목 내용 뿌려주기
		    List<ReplyVO> replyList=rmapper.replyList(bno);
		    log.info("보드정보"+board);
		    log.info("댓글정보"+replyList);
		    model.addAttribute("replyList",replyList);
			model.addAttribute("dto", dto);			//페이지 기억을위해 페이지값 전달
			model.addAttribute("board", board);     //게시물 내용값  전달
		
			return "/board/read";					//클릭했으니 조회수 증가시켜주기
		}else{
			log.info("처음이니 조회수 증가해줄게");   
			mapper.viewCnt(bno);                    //클릭했으니 조회수 증가시켜주기
			BoardVO board = mapper.selectRead(bno);  //클릭한 게시물 제목 내용 뿌려주기
			List<ReplyVO> replyList=rmapper.replyList(bno);
			log.info("댓글정보"+replyList);
		    log.info("보드정보"+board);
		    model.addAttribute("repryList",replyList);
			model.addAttribute("dto", dto);			//페이지 기억을위해 페이지값 전달
			model.addAttribute("board", board);     //게시물 내용값  전달
			return "/board/read";
			
		}
		}

	@PostMapping("/read")// 수정페이지->수정버튼 Click시 조회 페이지
	public String read(AlterDTO dao, Model model, PagingDTO dto) {

		mapper.updateAlter(dao);			             //변경한값 DB에 저장
		BoardVO board = mapper.selectRead(dao.getBno()); //해당 bno 게시물 수정된거 뿌려줌
		model.addAttribute("dto", dto);                  //모델에 초기페이지값 저장
		model.addAttribute("board", board);		         //모델에 변경된 게시물내용 저장
		return "/board/read";

	}

	@PostMapping("/update")//수정페이지
	public String update(AlterDTO dao, Model model, PagingDTO dto) {
		log.info(dao); 										// 수정하러 왔을때
		log.info("/update");
		BoardVO update = mapper.selectRead(dao.getBno());   //화면에 해당게시물번호 제목 내용 뿌려줌
		model.addAttribute("dto", dto);   				    //초기 페이지값 저장
		model.addAttribute("update", update); 				//현재 페이지값 저장
		return "/board/update";

	}

	@GetMapping("/login")//로그인페이지
	public void login() {

		log.info("get login..........");

	}

	

	@GetMapping("/insertPost")
	public void insertPost() {


	}
	
	@PostMapping("/insertPost")
	public void insertPost(PagingDTO dto, Model model) {

		log.info(dto);
		log.info("get insertPost....");
		model.addAttribute("dto", dto); 

	}

	@PostMapping("/POSTpost") // 글 등록 POST
	public String POSTinsertPost(BoardVO vo) {

		mapper.insertBoard(vo);

		return "redirect:/board/list";

	}

}
