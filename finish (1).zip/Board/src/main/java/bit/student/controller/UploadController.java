package bit.student.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.http.HttpRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import bit.student.dto.uploadFileDTO;
import lombok.extern.log4j.Log4j;
import net.coobird.thumbnailator.Thumbnailator;

@Log4j
@RestController
@RequestMapping("/board/*")
public class UploadController {
	
	private String fileFolder() { // 날짜에 맞는 폴더에 파일 생성
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String str = sdf.format(date);
		
		return str.replace("-", File.separator);
		
	}
	
	private boolean checkImageType(File file) { // 이미지 파일인지 확인
		try {
			String contentType = Files.probeContentType(file.toPath());
			
			return contentType.startsWith("image");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	@GetMapping("/displayFile")
	@ResponseBody
	public ResponseEntity<byte[]> displayFile(String fileName) { // 이미지 표시
		String uploadFolder = "C:\\upload";
		File uploadPath = new File(uploadFolder, fileFolder());
		File file = new File(uploadPath, fileName);

		try {
			String mimeType = Files.probeContentType(file.toPath());

			HttpHeaders header = new HttpHeaders();
			header.add("Content-Type", mimeType);

			byte[] data = FileCopyUtils.copyToByteArray(file);

			return new ResponseEntity<>(data, header, HttpStatus.OK);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}
	
	@PostMapping("/uploadFile")
	public ResponseEntity<List<uploadFileDTO>> POSTuploadFile(MultipartFile[] Files, Model model) { // 파일등록
		log.info("Post UploadFile..........");
		String uploadFolder = "C:\\upload";
		List<uploadFileDTO> list = new ArrayList<>();
		
		for (MultipartFile multipartfile : Files) {
			if (!multipartfile.isEmpty()) {
				
				
				uploadFileDTO dto = new uploadFileDTO();
				
				File uploadPath = new File(uploadFolder, fileFolder());
				dto.setFilePath(uploadPath.getAbsolutePath());
				
				if(!uploadPath.exists()) { // 경로에 폴더가 없으면 폴더 생성
					uploadPath.mkdirs();
				}
				
				UUID uuid = UUID.randomUUID();
				String fileName = uuid.toString() + "_" + multipartfile.getOriginalFilename();
				dto.setFileName(fileName);
				dto.setUuid(uuid.toString());
				
				log.info("=========================================");
				log.info("File Name : " + multipartfile.getOriginalFilename());
				log.info("File Size : " + multipartfile.getSize());
				File saveFile = new File(uploadPath, fileName);
				dto.setImageVali(checkImageType(saveFile));
				
				try {
					multipartfile.transferTo(saveFile);
					list.add(dto);
					if (checkImageType(saveFile)) {
						FileOutputStream thumbnail = new FileOutputStream(new File(uploadPath, "s_" + fileName));
						Thumbnailator.createThumbnail(multipartfile.getInputStream(), thumbnail, 100, 100);
						thumbnail.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		return new ResponseEntity<List<uploadFileDTO>>(list, HttpStatus.OK);
	}
	
}
