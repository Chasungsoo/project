package bit.student.mapper;

import java.util.List;

import bit.student.domain.BoardVO;
import bit.student.domain.ReplyVO;




public interface ReplyMapper {
	
	public List<ReplyVO> replyList(Integer bno);//페이지뿌리기
	
	public int delete(Integer rno);//삭제

	public boolean insertReply(ReplyVO vo);//등록

}
