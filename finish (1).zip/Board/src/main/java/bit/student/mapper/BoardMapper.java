package bit.student.mapper;

import java.util.List;

import bit.student.domain.BoardVO;
import bit.student.dto.AlterDTO;
import bit.student.dto.PagingDTO;


public interface BoardMapper {

	public List<BoardVO> selectList(PagingDTO dto);//페이지뿌리기

	public BoardVO selectRead(Integer bno);//조회

	public boolean updateAlter(AlterDTO dto);//수정

	public int delete(Integer bno);//삭제

	public boolean insertBoard(BoardVO vo);//등록
	
	public int viewCnt(Integer bno);//viewCnt 증가
	
	public int listCount(PagingDTO dto);//페이지처리

}
