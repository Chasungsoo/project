package bit.student.dto;

import lombok.Data;

@Data
public class PagingDTO {
	
	private int page = 1; 
	private int amount = 10;
	private String type, keyword;
	
	public int getSkip() {
		
		return (page -1) * amount;
		
	}
	public String[] getTypeArr() {
		return type==null?new String[] {}: type.split("");
	}


}
