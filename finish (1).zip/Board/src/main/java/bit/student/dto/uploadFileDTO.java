package bit.student.dto;

import lombok.Data;

@Data
public class uploadFileDTO {
	
	private String fileName;
	private String filePath;
	private String uuid;
	private boolean imageVali;

}
