package bit.student.dto;

import lombok.Data;

@Data
public class AlterDTO {
	private Integer bno;
	private String content,title;
}
