package bit.student.dto;

import bit.student.dto.PagingDTO;
import lombok.Data;

@Data
public class PageMaker {
	
	private int total, endPage, startPage;
	private boolean prev, next;
    private PagingDTO dto;
	
    public PageMaker(PagingDTO dto, int total) {
    	this.dto = dto;
    	this.total = total;
    	
    	int tempEnd = (int)(Math.ceil(dto.getPage()/10.0)) * 10;
		this.startPage = tempEnd - 9;
    	
    	this.prev = startPage != 1;
    	
    	int realEnd = 
				(int)(Math.ceil(total/(double)dto.getAmount()));
		
		if(realEnd < tempEnd) {
			this.endPage = realEnd;
		}else {
			this.endPage = tempEnd;
		}
		
		
		this.next = this.endPage * dto.getAmount() < total;
    }
	
}
