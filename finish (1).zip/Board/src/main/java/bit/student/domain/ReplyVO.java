package bit.student.domain;

import java.util.Date;

import lombok.Data;


@Data
public class ReplyVO {
	
	private Integer rno,bno;
	private String writer,content;
	private Date regdate;

}
