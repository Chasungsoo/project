package bit.student.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import bit.student.domain.BoardVO;
import bit.student.mapper.BoardMapper;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class boardTest {
	
	@Autowired
	BoardMapper mapper;
	
//	@Test
//	public void listTest() {
//		log.info(mapper.selectList());
//	}
	@Test
	public void list2Test() {
		BoardVO vo = new BoardVO();
	
//		log.info(mapper.selectRead();
	}

}
